import { Fragment, useEffect, useState } from "react";
import axios from "axios";
import { useDispatch, useSelector } from "react-redux";
import { fetchGames, getGamesSuccess, isError } from "../store/games";
import { Link } from "react-router-dom";

export default function GameDetail() {
  const dispatch = useDispatch();
  const { data, errors, loading } = useSelector((state) => state.game);

  useEffect(() => {
    dispatch(fetchGames());
  }, []);

  return (
    <div className="container mx-auto mt-20 bg-navy rounded">
      <a
        href="#"
        className="block rounded-lg p-4 shadow-sm shadow-indigo-100 mx-auto grid grid-cols-3 gap-3">
        <img
          alt=""
          src=""
          className="rounded-md object-cover"
          height={700}
          width={700}
        />

        <div className="mt-2">
          <dl>
            <div>
              <dt className="font-bold text-xl text-custom-sky">Name</dt>
              <dd className="text-xl text-white">Duer</dd>
            </div>
            <div className="mt-10">
              <dt className="font-bold text-xl text-custom-sky">Facility</dt>
              <dd className="text-xl text-white">Duer</dd>
            </div>
            <div className="mt-5">
              <dt className="font-bold text-xl text-custom-sky">
                Room Capacity
              </dt>
              <dd className="text-xl text-white">Duer</dd>
            </div>
          </dl>
        </div>
        <div className="mt-2">
          <div className="">
            <dt className="font-bold text-xl text-custom-sky">Location</dt>

            <dd className="font-xl text-white">Duer</dd>
          </div>
          <div className="mt-10">
            <dt className="font-bold text-xl text-custom-sky">Type</dt>
            <dd className="text-xl text-white">Duer</dd>
          </div>
          <div className="mt-10">
            <dt className="font-bold text-xl text-custom-sky">Owner</dt>
            <dd className="text-xl text-white">Duer</dd>
          </div>
        </div>
      </a>
    </div>
  );
}
